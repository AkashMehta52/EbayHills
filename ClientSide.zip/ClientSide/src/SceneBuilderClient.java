import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

/*
 * Author: Vallath Nandakumar and the EE 422C Instructors
 * Date: April 20, 2020
 * This code is for starting  out your JavaFX application from SceneBuilder. It doesn't compile.
 */
public class SceneBuilderClient extends Application {

    ClientLoginController controller;
    ObjectInputStream reader;
    ObjectOutputStream writer;
    private static ArrayList<clientUser> userInfo = new ArrayList<>();
    private static Stage stg;

    public static ArrayList<clientUser> getUserInfo(){
        return userInfo;
    }

    public static boolean containsUser(clientUser user){
        if(userInfo.contains(user)){
            return true;
        }
        return false;
    }
    public static void updateUserInfo(clientUser newUser){
        userInfo.add(newUser);
    }

    @Override
    public void start(Stage primaryStage) throws Exception{
        stg = primaryStage;
        primaryStage.setResizable(false);
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent root = fxmlLoader.load(getClass().getResource("loginSplash.fxml").openStream());
        controller = fxmlLoader.getController();
        primaryStage.setTitle("Log-In");
        primaryStage.setScene(new Scene(root, 763, 524));
        primaryStage.show();
        controller.myClient = this;
        //customer = new Customer("", "");
        connectToServer();
    }

    public void changeScene(String fxml, clientUser user) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent pane = fxmlLoader.load(getClass().getResource(fxml));
        //need to set a controller instance here, and send the user information to this controller!
        Stage stage = (Stage) stg.getScene().getWindow();
        stage.setScene(new Scene(pane));
        stage.show();
        stage.setUserData(user);
        //connectToServer();
    }

    void connectToServer () {
        int port = 5000;
        try {
            Socket sock = new Socket("localhost", port);
            writer = new ObjectOutputStream(sock.getOutputStream());
            reader = new ObjectInputStream(sock.getInputStream());
            System.out.println("networking established");
            Thread readerThread = new Thread(new IncomingReader()); // see Canvas's Chat for IncomingReader class
            readerThread.start();

        } catch (IOException e) {}
    }

    //ClientLoginController getController () { return controller; }

    public static void main(String[] args){
        launch(args);
    }

    class IncomingReader implements Runnable {
        public void run() {
            controller.setIO(writer, reader);
            String message;
            try {
                synchronized(reader){
                    while ((message = reader.readLine()) != null) {
                        //incoming.append(message + "\n");
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}

